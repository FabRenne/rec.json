package com.example.moutures2.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.moutures2.data.Mouture
import com.example.moutures2.data.MouturesData
import com.example.moutures2.ui.theme.MouturesTheme

/**
 * L'écran principal, relié au ViewModel.
 */
@Composable
fun MouturesScreen(
    sombre: Boolean,
    onSombreChange: (Boolean) -> Unit,
    viewModel: MoutureViewModel = viewModel(),
) {
    val etat by viewModel.uiState.collectAsStateWithLifecycle()
    MouturesContent(
        etat = etat,
        sombre = sombre,
        onSombreChange = onSombreChange,
        onMoutureClick = viewModel::onMoutureClick,
    )
}

/**
 * Le contenu de l'écran. Il ne reçoit que des données et des fonctions :
 * on peut donc l'afficher dans un aperçu (@Preview) sans ViewModel.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MouturesContent(
    etat: MouturesUiState,
    sombre: Boolean,
    onSombreChange: (Boolean) -> Unit,
    onMoutureClick: (Mouture) -> Unit,
) {
    val listState = rememberLazyListState()

    // À chaque nouvelle sélection, on remonte en haut pour voir la carte de détail.
    LaunchedEffect(etat.selection) {
        if (etat.selection != null) listState.animateScrollToItem(0)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Moutures") },
                actions = {
                    // Bouton qui bascule entre le thème clair et le thème sombre.
                    IconButton(onClick = { onSombreChange(!sombre) }) {
                        Text(text = if (sombre) "☀️" else "🌙", fontSize = 20.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            )
        },
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // 1) La carte de détail, en tête de liste.
            etat.selection?.let { mouture ->
                item(key = "detail") {
                    DetailMouture(mouture)
                }
            }

            // 2) Une ligne par mouture.
            items(etat.moutures, key = { it.nom }) { mouture ->
                LigneMouture(
                    mouture = mouture,
                    selectionnee = mouture.nom == etat.selection?.nom,
                    onClick = { onMoutureClick(mouture) },
                )
            }
        }
    }
}

// ---------- Aperçus dans Android Studio ----------

@Preview(name = "Thème clair", showBackground = true)
@Composable
private fun ApercuClair() {
    MouturesTheme(darkTheme = false) {
        MouturesContent(
            etat = MouturesUiState(
                moutures = MouturesData.moutures,
                selection = MouturesData.moutures[1],
            ),
            sombre = false,
            onSombreChange = {},
            onMoutureClick = {},
        )
    }
}

@Preview(name = "Thème sombre", showBackground = true)
@Composable
private fun ApercuSombre() {
    MouturesTheme(darkTheme = true) {
        MouturesContent(
            etat = MouturesUiState(
                moutures = MouturesData.moutures,
                selection = MouturesData.moutures[1],
            ),
            sombre = true,
            onSombreChange = {},
            onMoutureClick = {},
        )
    }
}
