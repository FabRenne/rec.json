package com.example.moutures2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.example.moutures2.ui.MouturesScreen
import com.example.moutures2.ui.theme.MouturesTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            // Au démarrage, on prend le réglage du téléphone (clair ou sombre).
            val systemeSombre = isSystemInDarkTheme()
            // rememberSaveable : le choix est conservé si on tourne l'écran.
            var sombre by rememberSaveable { mutableStateOf(systemeSombre) }

            // Couleur des icônes système (heure, batterie, barre de navigation).
            // En thème clair, la barre du haut est brun foncé : icônes blanches en haut.
            // En thème sombre, elle est beige clair : icônes foncées en haut.
            DisposableEffect(sombre) {
                val transparent = android.graphics.Color.TRANSPARENT
                val iconesClaires = SystemBarStyle.dark(transparent)
                val iconesFoncees = SystemBarStyle.light(transparent, transparent)
                enableEdgeToEdge(
                    statusBarStyle = if (sombre) iconesFoncees else iconesClaires,
                    navigationBarStyle = if (sombre) iconesClaires else iconesFoncees,
                )
                onDispose { }
            }

            MouturesTheme(darkTheme = sombre) {
                MouturesScreen(
                    sombre = sombre,
                    onSombreChange = { sombre = it },
                )
            }
        }
    }
}
