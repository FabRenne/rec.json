package com.example.moutures2.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val CouleursClaires = lightColorScheme(
    primary = ClairPrimary,
    onPrimary = ClairOnPrimary,
    primaryContainer = ClairPrimaryContainer,
    onPrimaryContainer = ClairOnPrimaryContainer,
    secondaryContainer = ClairSecondaryContainer,
    onSecondaryContainer = ClairOnSecondaryContainer,
    tertiary = ClairTertiary,
    background = ClairBackground,
    onBackground = ClairOnBackground,
    surface = ClairBackground,
    onSurface = ClairOnBackground,
    surfaceVariant = ClairSurfaceVariant,
    onSurfaceVariant = ClairOnSurfaceVariant,
    outline = ClairOutline,
    error = ClairError,
)

private val CouleursSombres = darkColorScheme(
    primary = SombrePrimary,
    onPrimary = SombreOnPrimary,
    primaryContainer = SombrePrimaryContainer,
    onPrimaryContainer = SombreOnPrimaryContainer,
    secondaryContainer = SombreSecondaryContainer,
    onSecondaryContainer = SombreOnSecondaryContainer,
    tertiary = SombreTertiary,
    background = SombreBackground,
    onBackground = SombreOnBackground,
    surface = SombreBackground,
    onSurface = SombreOnBackground,
    surfaceVariant = SombreSurfaceVariant,
    onSurfaceVariant = SombreOnSurfaceVariant,
    outline = SombreOutline,
    error = SombreError,
)

/**
 * Le thème de l'application.
 * darkTheme = true  → couleurs sombres
 * darkTheme = false → couleurs claires
 * Par défaut, on suit le réglage du téléphone.
 */
@Composable
fun MouturesTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) CouleursSombres else CouleursClaires,
        content = content,
    )
}
