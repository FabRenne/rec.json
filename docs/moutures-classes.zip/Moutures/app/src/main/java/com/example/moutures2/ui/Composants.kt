package com.example.moutures2.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.moutures2.data.Dosage
import com.example.moutures2.data.Mouture

/** Texte affiché quand une information est absente (null). */
const val VIDE = "—"

/**
 * Une ligne de la liste. Elle change de couleur quand elle est sélectionnée.
 */
@Composable
fun LigneMouture(
    mouture: Mouture,
    selectionnee: Boolean,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (selectionnee) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
        ),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = mouture.nom,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = "SM ${mouture.sansMeule.vitesseBle}/${mouture.sansMeule.vitesseDoseur}" +
                    " · AM ${mouture.avecMeule.vitesseBle}/${mouture.avecMeule.vitesseDoseur}",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

/**
 * La carte de détail de la mouture sélectionnée.
 */
@Composable
fun DetailMouture(mouture: Mouture) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer,
        ),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = mouture.nom,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )

            TableauDosage(sansMeule = mouture.sansMeule, avecMeule = mouture.avecMeule)

            val info = mouture.info
            LigneInfo("Gruau", info.gruau ?: VIDE)
            LigneInfo("Améliorant", info.ameliorant ?: VIDE)
            LigneInfo("Mignon", info.mignon ?: VIDE)
            IconesRemoulage(titre = "Remoulage", valeurs = info.remoulage)
            LigneInfo("Dév. sûreté", if (info.devSurete) "Oui" else "Non")
        }
    }
}

/**
 * Tableau des vitesses : 3 colonnes (libellé, sans meule, avec meule).
 */
@Composable
fun TableauDosage(sansMeule: Dosage, avecMeule: Dosage) {
    val trait = MaterialTheme.colorScheme.outline
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, trait, RoundedCornerShape(8.dp)),
    ) {
        LigneTableau("", "Sans meule", "Avec meule", entete = true)
        HorizontalDivider(thickness = 1.dp, color = trait)
        LigneTableau(
            "Vit. blé",
            sansMeule.vitesseBle.toString(),
            avecMeule.vitesseBle.toString(),
        )
        HorizontalDivider(thickness = 1.dp, color = trait)
        LigneTableau(
            "Vit. doseur",
            sansMeule.vitesseDoseur.toString(),
            avecMeule.vitesseDoseur.toString(),
        )
    }
}

@Composable
private fun LigneTableau(
    libelle: String,
    sansMeule: String,
    avecMeule: String,
    entete: Boolean = false,
) {
    val trait = MaterialTheme.colorScheme.outline
    // IntrinsicSize.Min donne une hauteur à la Row : sans ça, les traits verticaux sont invisibles.
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min),
    ) {
        CaseTableau(libelle, Modifier.weight(1.2f), gras = true, alignement = TextAlign.Start)
        VerticalDivider(thickness = 1.dp, color = trait)
        CaseTableau(sansMeule, Modifier.weight(1f), gras = entete)
        VerticalDivider(thickness = 1.dp, color = trait)
        CaseTableau(avecMeule, Modifier.weight(1f), gras = entete)
    }
}

@Composable
private fun CaseTableau(
    texte: String,
    modifier: Modifier = Modifier,
    gras: Boolean = false,
    alignement: TextAlign = TextAlign.Center,
) {
    Text(
        text = texte,
        modifier = modifier.padding(horizontal = 8.dp, vertical = 6.dp),
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = if (gras) FontWeight.SemiBold else FontWeight.Normal,
        textAlign = alignement,
    )
}

/**
 * Une ligne « libellé ......... valeur ».
 */
@Composable
fun LigneInfo(libelle: String, valeur: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = libelle,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = valeur,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
        )
    }
}

/**
 * Une colonne avec le titre, puis une rangée d'icônes (une par case de remoulage) :
 * coche verte = oui, croix rouge = non.
 */
@Composable
fun IconesRemoulage(
    titre: String,
    valeurs: List<Boolean>,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            text = titre,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Toujours 3 icônes : s'il manque une valeur, on la considère « non ».
            List(3) { i -> valeurs.getOrElse(i) { false } }.forEachIndexed { i, actif ->
                Icon(
                    imageVector = if (actif) Icons.Filled.CheckCircle else Icons.Filled.Close,
                    contentDescription = "Remoulage ${i + 1} : ${if (actif) "oui" else "non"}",
                    tint = if (actif) {
                        MaterialTheme.colorScheme.tertiary
                    } else {
                        MaterialTheme.colorScheme.error
                    },
                    modifier = Modifier.size(28.dp),
                )
            }
        }
    }
}
