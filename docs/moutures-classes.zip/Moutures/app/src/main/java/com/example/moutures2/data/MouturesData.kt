package com.example.moutures2.data

/**
 * Toutes les moutures de l'application, écrites directement en Kotlin.
 *
 * Pour ajouter une mouture : copiez un bloc Mouture(...) complet,
 * collez-le à la fin de la liste (après une virgule) et changez les valeurs.
 */
object MouturesData {

    val moutures: List<Mouture> = listOf(
        Mouture(
            nom = "t55",
            sansMeule = Dosage(vitesseBle = 21, vitesseDoseur = 0),
            avecMeule = Dosage(vitesseBle = 0, vitesseDoseur = 0),
            info = InfoMouture(
                gruau = null,
                ameliorant = null,
                mignon = null,
                remoulage = listOf(false, false, false),
                devSurete = false,
            ),
        ),
        Mouture(
            nom = "Tradition",
            sansMeule = Dosage(vitesseBle = 21, vitesseDoseur = 72),
            avecMeule = Dosage(vitesseBle = 19, vitesseDoseur = 67),
            info = InfoMouture(
                gruau = "doseur à 18",
                ameliorant = "Floricreme",
                mignon = "doseur à 18",
                remoulage = listOf(true, false, false),
                devSurete = false,
            ),
        ),
        Mouture(
            nom = "Originale",
            sansMeule = Dosage(vitesseBle = 21, vitesseDoseur = 58),
            avecMeule = Dosage(vitesseBle = 19, vitesseDoseur = 55),
            info = InfoMouture(
                gruau = "doseur à 38",
                ameliorant = "Mill Tradi",
                mignon = "doseur à 18",
                remoulage = listOf(false, false, false),
                devSurete = false,
            ),
        ),
    )
}
