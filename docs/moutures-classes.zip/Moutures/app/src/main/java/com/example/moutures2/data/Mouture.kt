package com.example.moutures2.data

/**
 * Les réglages de vitesse pour un mode de mouture (sans meule ou avec meule).
 */
data class Dosage(
    val vitesseBle: Int,
    val vitesseDoseur: Int,
)

/**
 * Les informations complémentaires d'une mouture.
 * Un type suivi de « ? » (String?) peut valoir null : l'information est absente.
 */
data class InfoMouture(
    val gruau: String?,
    val ameliorant: String?,
    val mignon: String?,
    val remoulage: List<Boolean>,
    val devSurete: Boolean,
)

/**
 * Une mouture complète : son nom, ses deux réglages et ses informations.
 */
data class Mouture(
    val nom: String,
    val sansMeule: Dosage,
    val avecMeule: Dosage,
    val info: InfoMouture,
)
