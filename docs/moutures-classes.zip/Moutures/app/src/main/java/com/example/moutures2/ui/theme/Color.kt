package com.example.moutures2.ui.theme

import androidx.compose.ui.graphics.Color

// ---------- Thème clair ----------
val ClairPrimary = Color(0xFF7A5A2E)            // brun farine
val ClairOnPrimary = Color(0xFFFFFFFF)
val ClairPrimaryContainer = Color(0xFFF6DFC0)
val ClairOnPrimaryContainer = Color(0xFF2B1700)
val ClairSecondaryContainer = Color(0xFFFBEBC4) // blé clair
val ClairOnSecondaryContainer = Color(0xFF3E2C10)
val ClairTertiary = Color(0xFF2E7D32)           // vert : « oui »
val ClairBackground = Color(0xFFFFFBF6)
val ClairOnBackground = Color(0xFF1F1B16)
val ClairSurfaceVariant = Color(0xFFEFE3D3)
val ClairOnSurfaceVariant = Color(0xFF4F4539)
val ClairOutline = Color(0xFF817567)
val ClairError = Color(0xFFB3261E)

// ---------- Thème sombre ----------
val SombrePrimary = Color(0xFFE9C08A)
val SombreOnPrimary = Color(0xFF442B05)
val SombrePrimaryContainer = Color(0xFF5E4219)
val SombreOnPrimaryContainer = Color(0xFFF6DFC0)
val SombreSecondaryContainer = Color(0xFF4A3B1E)
val SombreOnSecondaryContainer = Color(0xFFFBEBC4)
val SombreTertiary = Color(0xFF81C784)
val SombreBackground = Color(0xFF17130E)
val SombreOnBackground = Color(0xFFEBE1D6)
val SombreSurfaceVariant = Color(0xFF3A3128)
val SombreOnSurfaceVariant = Color(0xFFD3C4B2)
val SombreOutline = Color(0xFF9C8F80)
val SombreError = Color(0xFFF2B8B5)
