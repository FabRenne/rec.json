package com.example.moutures2.ui

import androidx.lifecycle.ViewModel
import com.example.moutures2.data.Mouture
import com.example.moutures2.data.MouturesData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Tout ce que l'écran doit afficher à un instant donné.
 */
data class MouturesUiState(
    val moutures: List<Mouture> = emptyList(),
    val selection: Mouture? = null,
)

/**
 * Garde l'état de l'écran. Il survit à la rotation du téléphone :
 * la mouture sélectionnée n'est pas perdue.
 */
class MoutureViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(
        MouturesUiState(
            moutures = MouturesData.moutures,
            // Au démarrage, la première mouture est sélectionnée.
            selection = MouturesData.moutures.firstOrNull(),
        )
    )
    val uiState: StateFlow<MouturesUiState> = _uiState.asStateFlow()

    /** Appelé quand l'utilisateur touche une ligne de la liste. */
    fun onMoutureClick(mouture: Mouture) {
        _uiState.update { etat -> etat.copy(selection = mouture) }
    }
}
