# Moutures — version sans JSON

Application Android (Kotlin + Jetpack Compose) qui affiche des moutures et leurs réglages.
Les données sont écrites directement en Kotlin dans `data/MouturesData.kt`.

## Ouvrir le projet
1. Android Studio → File → Open → choisir ce dossier `Moutures`.
2. Attendre la synchronisation Gradle (Internet nécessaire la première fois).
3. Run ▶ sur un téléphone ou un émulateur.

## Où modifier quoi
| Je veux…                         | Fichier                              |
|----------------------------------|--------------------------------------|
| Ajouter / modifier une mouture   | `data/MouturesData.kt`               |
| Changer les couleurs             | `ui/theme/Color.kt`                  |
| Modifier la carte, le tableau    | `ui/Composants.kt`                   |
| Modifier l'écran principal       | `ui/MouturesScreen.kt`               |

Le bouton lune / soleil en haut à droite bascule entre le thème clair et le thème sombre.
Le cours complet pour débutants est dans `cours-moutures-classes.pdf`.
